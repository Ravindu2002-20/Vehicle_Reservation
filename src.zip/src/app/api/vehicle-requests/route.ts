import { NextResponse } from "next/server";
import { getCurrentUser } from "@/lib/current-user";
import { prisma } from "@/lib/prisma";

export async function POST(req: Request) {
  const currentUser = await getCurrentUser();
  if (!currentUser || currentUser.type !== "user") {
    return NextResponse.json({ error: "Unauthorized" }, { status: 401 });
  }

  // Accept multipart/form-data
  const contentType = req.headers.get("content-type") || "";
  const isMultipart = contentType.toLowerCase().includes("multipart/form-data");

  if (!isMultipart) {
    return NextResponse.json({ error: "Expected multipart/form-data" }, { status: 400 });
  }

  const formData = await req.formData();
  const file = formData.get("request_letter") as unknown as File | null;
  if (!file) {
    return NextResponse.json({ error: "request_letter is required" }, { status: 400 });
  }

  if ((file as File).type !== "application/pdf") {
    return NextResponse.json({ error: "Only application/pdf is allowed" }, { status: 400 });
  }

  const {
    path_type,
    vehicleDetails,
    requestDate,
    purpose,
    target_deputy_role,
  } = Object.fromEntries(formData) as any;

  if (!path_type) {
    return NextResponse.json({ error: "Missing path_type" }, { status: 400 });
  }


  if (!["via_dean", "skip_dean"].includes(path_type)) {
    return NextResponse.json({ error: "Invalid path_type" }, { status: 400 });
  }

  const initialStatus =
    path_type === "via_dean" ? "pending_dean" : "pending_admin_deputy";

  // NOTE: This route currently only creates a minimal request record.
  // Phase 3 requires initial approval_status based on path_type.
  const created = await prisma.vehicleRequest.create({
    data: {
      requester_id: currentUser.id,
      path_type,
      request_type: "official",
      vehicle_nature: "university_owned",
      number_of_persons: 1,
      travel_date_from: new Date(requestDate),
      travel_date_to: new Date(requestDate),
      required_time_from: "09:00",
      required_time_to: "17:00",
      purpose: purpose ?? "",
      distance_type: "local",
      approval_status: initialStatus,
      allocation_status: "pending",
    },
  });

  const requestLetterBytes = Buffer.from(await (file as File).arrayBuffer());
  const fs = await import("fs");
  const path = await import("path");

  const uploadDir = path.join(process.cwd(), "uploads", "request-letters");
  fs.mkdirSync(uploadDir, { recursive: true });

  const filePath = path.join(uploadDir, `request_${created.id}.pdf`);
  fs.writeFileSync(filePath, requestLetterBytes);

  const request_letter_path = `/uploads/request-letters/request_${created.id}.pdf`;

  await prisma.vehicleRequest.update({
    where: { id: created.id },
    data: { request_letter_path },
  });




  return NextResponse.json({ data: created });
}

export async function GET(req: Request) {
  const currentUser = await getCurrentUser();
  if (!currentUser) return NextResponse.json({ error: "Unauthorized" }, { status: 401 });

  const statusByRole: Record<string, string> = {
    dean: "pending_dean",
    "admin-deputy": "pending_admin_deputy",
    "university-deputy": "pending_university_deputy",
    "senior-officer": "approved_for_allocation",
  };

  const visibleStatus = statusByRole[currentUser.role];

  const where: any = visibleStatus
    ? { approval_status: visibleStatus }
    : { requester_id: currentUser.id };

  if (currentUser.role === "dean") {
    const dean = await prisma.admin.findUnique({ where: { id: currentUser.id } });
    if (dean?.faculty_id == null) {
      return NextResponse.json({ error: "Forbidden" }, { status: 403 });
    }

    where.requester = {
      department: { faculty_id: dean.faculty_id },
    };
  }

  const items = await prisma.vehicleRequest.findMany({
    where,
    orderBy: { created_at: "desc" },
    include: {
      requester: {
        include: {
          department: {
            include: { faculty: true },
          },
        },
      },
      vehicle: true,
      driver: true,
    },
  });

  return NextResponse.json({ data: items });
}



